export const API_VERSION = Object({
    'dev': '/signalevanto/backend/public/api/v1',
    'prod': '/backend/api/v1'
});
