<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 27/08/2019
 * Time: 15:56
 */

namespace App\SmartMicro\Repositories\Contracts;

interface ExpenseInterface extends BaseInterface {}