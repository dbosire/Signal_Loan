<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 03/06/2019
 * Time: 11:01
 */

namespace App\SmartMicro\Repositories\Contracts;

interface GeneralSettingInterface extends BaseInterface
{
}