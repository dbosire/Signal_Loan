<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 02/08/2019
 * Time: 11:48
 */

namespace App\SmartMicro\Repositories\Contracts;

interface EmailSettingInterface extends BaseInterface
{}