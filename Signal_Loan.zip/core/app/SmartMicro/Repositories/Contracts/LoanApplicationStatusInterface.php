<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 27/10/2018
 * Time: 12:44
 */

namespace App\SmartMicro\Repositories\Contracts;

interface LoanApplicationStatusInterface extends BaseInterface {
}