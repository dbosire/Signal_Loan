<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 24/11/2019
 * Time: 17:45
 */

namespace App\SmartMicro\Repositories\Contracts;

interface CommunicationSettingInterface extends BaseInterface
{}