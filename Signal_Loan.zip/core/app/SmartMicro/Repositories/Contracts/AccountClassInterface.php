<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 28/08/2019
 * Time: 14:20
 */

namespace App\SmartMicro\Repositories\Contracts;

interface AccountClassInterface extends BaseInterface
{
}