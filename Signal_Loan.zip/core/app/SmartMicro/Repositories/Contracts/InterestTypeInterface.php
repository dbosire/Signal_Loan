<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 07/08/2019
 * Time: 08:50
 */

namespace App\SmartMicro\Repositories\Contracts;

interface InterestTypeInterface extends BaseInterface
{}