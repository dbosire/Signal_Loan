<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 02/11/2019
 * Time: 20:31
 */

namespace App\SmartMicro\Repositories\Contracts;

interface CapitalInterface extends BaseInterface
{
}