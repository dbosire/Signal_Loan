<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 27/10/2018
 * Time: 12:38
 */

namespace App\SmartMicro\Repositories\Contracts;

interface GuarantorInterface extends BaseInterface {
}