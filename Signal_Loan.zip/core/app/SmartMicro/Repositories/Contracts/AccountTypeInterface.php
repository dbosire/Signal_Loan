<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 02/08/2019
 * Time: 10:31
 */

namespace App\SmartMicro\Repositories\Contracts;

interface AccountTypeInterface extends BaseInterface
{}