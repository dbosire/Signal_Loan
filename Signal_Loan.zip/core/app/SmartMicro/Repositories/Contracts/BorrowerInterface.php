<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 26/10/2018
 * Time: 12:10
 */

namespace App\SmartMicro\Repositories\Contracts;


interface BorrowerInterface extends BaseInterface {}