<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 26/10/2018
 * Time: 21:39
 */

namespace App\SmartMicro\Repositories\Contracts;

interface BranchInterface extends BaseInterface {}