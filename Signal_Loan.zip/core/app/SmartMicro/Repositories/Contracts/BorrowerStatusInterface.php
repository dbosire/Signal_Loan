<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 27/10/2018
 * Time: 12:50
 */

namespace App\SmartMicro\Repositories\Contracts;

interface BorrowerStatusInterface extends BaseInterface {


}