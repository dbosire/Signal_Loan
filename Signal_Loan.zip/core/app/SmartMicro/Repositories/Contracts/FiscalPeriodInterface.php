<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 27/08/2019
 * Time: 16:54
 */

namespace App\SmartMicro\Repositories\Contracts;

interface FiscalPeriodInterface extends BaseInterface
{}