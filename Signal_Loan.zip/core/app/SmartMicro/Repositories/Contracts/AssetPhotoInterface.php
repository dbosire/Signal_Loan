<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 11/07/2019
 * Time: 13:25
 */

namespace App\SmartMicro\Repositories\Contracts;

interface AssetPhotoInterface extends BaseInterface
{}