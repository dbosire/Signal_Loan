<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Email: robisignals@gmail.com
 * Date: 02/11/2019
 * Time: 22:59
 */

namespace App\SmartMicro\Repositories\Contracts;

interface EmailTemplateInterface extends BaseInterface
{
}